package chefcharlesmich.smartappphonebook.VcardProgram;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import chefcharlesmich.smartappphonebook.R;

public class AboutActivityVcard extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_vcard);
    }
}
